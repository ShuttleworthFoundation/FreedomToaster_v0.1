#!/usr/bin/perl
use strict;
use warnings;
use POSIX ":sys_wait_h"; # make WNOHANG available

################################################################################
# Functions that are system-specific
################################################################################

sub get_date {
   my @days = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
   my @months = ('January','February','March','April','May','June','July',
	      'August','September','October','November','December');

   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
   if ($hour < 10) { $hour = "0$hour"; }
   if ($min < 10) { $min = "0$min"; }
   if ($sec < 10) { $sec = "0$sec"; }
   $mon += 1;
   $year += 1900;

   my $date = "$year\:$mon\:$mday $hour\:$min\:$sec";
   return $date;
}

sub makeVolumeBaseName {
################################################################################
# Purpose: Creates a four-letter random code to give to volume labels to keep them unique
################################################################################
   my @chars = ( "A" .. "Z", "a" .. "z", 0 .. 9 );
   return join("", @chars[ map { rand @chars } ( 1 .. 4 ) ]);
}

sub burnMedium {
################################################################################
# Purpose: Calls the system to do a generic CD or DVD burn - new version
# Input  : $resource    - the cdrw device to burn to (in form cdrwn) 
#          \@distroIsos - full paths to the iso files to put onto this device
#          $medium      - CD or DVD
#          $volume      - volume identifier (for checking during updates...)
# Output : returns the string of output, AND
#          writes to /tmp/$resource the output while it is happening.  To get
#          burn progress, read /tmp/$resource and interpret it appropriately
################################################################################
   my ($resource, $distroIsos, $medium, $volume) = @_;
   my @distroISOs = @{$distroIsos};
   my $retval;
   my $isolist;
   my $burnlist;

   if ($medium eq 'CD') {
      $isolist = ','.$distroISOs[0];
      $retval = system "sudo cdrecord -s $main::CDRecordParms -v -eject -gracetime=0 -data dev=".$main::Devices{$resource}.' '. $distroISOs[0]. " > /tmp/$resource 2>&1";

      $retval = `grep '[0-9]* MB written' /tmp/$resource`;
      if (!($retval =~ s/^.*\r//)) {
	$retval .= 'Failed';
      } else {
        $retval =~ s/^[^:]\+:\s*//;
        $retval =~ s/written.*$/written/i;
      }

   } elsif ($medium eq 'DVD of CDs') {
      my $start = 1;
      foreach my $distroISO (@distroISOs) {
         $isolist .= ','.$distroISO;
         $burnlist .= $distroISO.' '; 
      }
      $retval = system "sudo growisofs -dvd-compat -use-the-force-luke=tty,dao -Z ".$main::Devices{$resource}." -r -R -V $volume $burnlist > /tmp/$resource 2>&1";
      $retval = readDVDStatus($resource);

   } elsif ($medium eq 'DVD') {
      $isolist = ','.$distroISOs[0];
      $retval = system "sudo growisofs -dvd-compat -use-the-force-luke=tty,dao -Z ".$main::Devices{$resource}."=".$distroISOs[0]." > /tmp/$resource 2>&1";
      $retval = readDVDStatus($resource);
   }

   open (LOGTOAST,">>$main::LogFile"); # or die "opening $main::LogFile : $!"; 
   my $dt=`date +"%Y-%m-%d %H:%M:%S"`;
   chomp $dt;
   print LOGTOAST "$main::ToasterName,$dt,$resource,$medium,".chomp($retval).$isolist."\n";
   close LOGTOAST;

   system "sudo eject ".$main::Devices{$resource};
   return($retval);
}

sub blankMedium {
################################################################################
# Purpose: Blanks CDRW media
# Input  : $resource    - the cdrw device to blank (in form cdrwn) 
# Output : returns the string of output, AND
#          writes to /tmp/$resource the output while it is happening.  To get
#          burn progress, read /tmp/$resource and interpret it appropriately
################################################################################
   my ($resource,$medium) = @_;
   my $retval;

   if ($medium =~ m/CD/) {
      if ($retval=system("sudo cdrecord -s $main::CDRecordParms -vv -s -eject -gracetime=2 -blank=fast dev=".$main::Devices{$resource}." > /tmp/$resource 2>&1")) {
         $retval = system("sudo cdrecord -s $main::CDRecordParms -vv -s -eject -gracetime=2 -force -blank=all dev=".$main::Devices{$resource}." > /tmp/$resource 2>&1");
      } 
      if ($retval eq 0) {
         $retval = "Disk Blanked";
      } else {
         $retval = "Blanking failed";
      }
   } elsif ($medium =~ m/DVD/) {
	   $retval = system "sudo mount ".$main::Devices{$resource}." && sudo dvd+rw-format -blank ".$main::Devices{$resource}." > /tmp/$resource 2>&1";

      $retval = `tail -1 /tmp/$resource | sed 's/.*\r//'`;
      chomp $retval;
      system "sudo eject ".$main::Devices{$resource};
   }
   return($retval);
}

sub readDVDStatus {
################################################################################
# Purpose: Assesses state of DVD Medium after writing
# Input  : $device    - the cdrw device, loaded (not ejected)
# Output : returns the status string for display on burners, AND
#          sets erasable.$device in the cache
################################################################################
   my ($resource) = @_;
   
   use Cache::FileCache;
   my $cache=new Cache::FileCache({-namespace => 'newKiosk'}) or die "Can't create file cache in newKiosk namespace";

   system "sudo mount ".$main::Devices{$resource};
   system "dvd+rw-mediainfo ".$main::Devices{$resource}." > /tmp/mediainfo.$resource 2>&1";
   if (`grep 'Mounted Media' /tmp/mediainfo.$resource | grep -c RW`) {
      $cache->set("erasable.$resource", 1);
   } else {
      $cache->set("erasable.$resource", 0);
   }
   return `grep 'State of Last Session:' /tmp/mediainfo.$resource | sed 's/.*: //' `;
}
sub findUnmountedCD {
################################################################################
# Purpose: Returns the device of any unmounted CD or DVD drive
# Input  : config.pl with a list of CDROMs configured
# Output : the first available device
# Created: Charles Oertel (2005/11/07) FineBushPeople.net
################################################################################
   my $cdrw;
   foreach $cdrw (keys %main::Devices) {
      if (system("mount | grep ".$main::Devices{$cdrw}." 2>/dev/null 1>&2")) {
         return $main::Devices{$cdrw};
      }
   }
}
sub getMountPath {
################################################################################
# Purpose: Returns the mount point path of a mounted device
# Input  : $device - the mounted device
# Output : returns the mount point
# Created: Charles Oertel (2005/11/07) FineBushPeople.net
################################################################################
   my ($device) = @_;
   my $retval = `mount | grep $device | egrep -o 'on [^ ]*' | sed 's/on //'`;
   chomp($retval);
   return '/home/charles/tmp';
   return $retval;
}

#sub showQueues() {
#################################################################################
## Purpose: Prints a count of what is in the queue
## Input  : Cache::FileCache
## Output : Printout of HTML showing queue (shopping cart)
## Created: Charles Oertel (2006/01/03) FineBushPeople.net
#################################################################################
#   use Cache::FileCache;
#   use CGI qw(:all);
#   my $q=new CGI;
#
#   my $cache=new Cache::FileCache({-namespace => 'newKiosk'}) or die "Cant create file cache";
#   my @DVDQueue = @{$cache->get('DVDQueue')};
#   my @CDQueue = @{$cache->get('CDQueue')};
#   my @CDontoDVDQueue = @{$cache->get('CDontoDVDQueue')};
#   my $BurnDVD;
## if (@CDontoDVDQueue) {
##      $BurnDVD = $q->a({-href=>"$main::CGIDir/distro.pl?task=BurnCDsontoDVD&distro=$distro"}, 
##                    $q->img({-src=>"$main::CSSDir/images/Toastem.png"}
##                    )
##                 );
##   }
#   print $q->table({-id=>'Queues',-cellspacing=>'20'},
#            $q->Tr(
#               $q->td(strong('CD Queue'), br(), int(@CDQueue), " items"),
#               $q->td(strong('DVD Queue'), br(), int(@DVDQueue), " items")
#                  ));
#   print $q->start_form({-action=>$main::CGIDir.'/showQueue.pl', -target=>'contentarea'});
#   print $q->submit({-value=>'toast selection'});
#   print $q->endform;
#}

return 1;
