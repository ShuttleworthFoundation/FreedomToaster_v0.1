#!/usr/bin/perl
###!/usr/bin/perl -w
#use strict;
#use warnings;
use Cache::FileCache;
use POSIX ":sys_wait_h"; # make WNOHANG available
use CGI  qw(:all);
require("config.pl");

my $cache=new Cache::FileCache({-namespace => 'cutLinux'}) or die "Cant create file cache";

our %jobs;                      # track pid -> resource
our @resource = keys %main::Devices;         # concurrent resources
my $num_resources = @resource;

my (@discs,@thisround);

$|=1;

#Get the distro we are about to cut now
my $distro = $cache->get('distro');
my $version = $cache->get('Version');
my $medium = $cache->get('Medium');

# Get the CD's that make up this distro
@discs= sort @{$cache->get('cds')};

# Remove only the first 3 discs
@thisround=splice @discs,0,3;

# put the remaining CD's back in the cache for next round
$cache->remove('cds');
$cache->set('cds',\@discs);

my $q = new CGI;
print $q->header;
print $q->start_html(-bgcolor =>'#EC870E',
                     -onload=>'window.close()');
print $q->end_html;
# Now get on and cut those CD's
# Clear some /tmp files to reset status from last burn
my $burner;
foreach $burner (@resource) {
	`rm -f /tmp/$burner > /dev/null 2>&1`;
}

my @Devices = @resource;

my $chld;
# Fork off burning processes...
open(OUTFILE,">>/tmp/cdimages.toasted");
my $date = get_date();
while (@thisround) {
	my @sort_resource = sort(@resource);
	@resource = @sort_resource;
	while (@resource) {
		last unless @thisround;
		my $resource = shift @resource;
		my $data = shift @thisround;
		if (($chld = fork()) > 0) {
			# parent code
		} else {
			# child code
			close(STDIN);
			close(STDERR);
			close(STDOUT);
			my $toasting = "toasting." . $resource;
			$cache->set($toasting,1);
			print (OUTFILE "$distro : $data ($medium) in $resource on $date : not yet done...");
                        my @Isos = ("$main::IsoDir/$distro/$version/$medium/$data");
         my $result = burnMedium($resource, \@Isos, $medium, $distro.'_'.$version );
			print (OUTFILE "$distro : $data ($medium) in $resource on $date | $result");
         $cache->set("$medium\:$data\:result", $result);
			$cache->set($toasting,0);
			alarm 0;
			exit;
		}
	}
   my $device;
   foreach $device (@Devices) {
      do {sleep 3;} while ($cache->get("toasting.$device")); 
   } 
}
close(OUTFILE);

