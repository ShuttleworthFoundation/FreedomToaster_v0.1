//
// user.js: Personal prefs which mozilla shouldn't overwrite.
//

// No warnings or other dialogs:
user_pref("security.warn_submit_insecure",false);
user_pref("signon.rememberSignons", false);
user_pref("browser.formfill.enable", false);

// Less memory wasted on history:
user_pref("browser.sessionhistory.max_entries", 1);
user_pref("browser.sessionhistory.max_total_viewers", 0);
user_pref("browser.sessionhistory.max_viewers", "0");
