
#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "configINT.h"
#include "configSTR.h"

#endif

